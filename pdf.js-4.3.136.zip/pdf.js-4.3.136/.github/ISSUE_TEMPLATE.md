Attach (recommended) or Link to PDF file here:

Configuration:
- Web browser and its version:
- Operating system and its version:
- PDF.js version:
- Is a browser extension:

Steps to reproduce the problem:
1. 
2.

What is the expected behavior? (add screenshot)

What went wrong? (add screenshot)

Link to a viewer (if hosted on a site other than mozilla.github.io/pdf.js or as Firefox/Chrome extension):
